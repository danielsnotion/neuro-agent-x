import onnx
import onnxruntime as ort
import numpy as np

MODEL_PATH = "submission.onnx"

# 🔹 Load model
model = onnx.load(MODEL_PATH)
onnx.checker.check_model(model)
print("✅ ONNX model structure valid")

# 🔹 Run inference
session = ort.InferenceSession(MODEL_PATH)

input_name = session.get_inputs()[0].name
output_name = session.get_outputs()[0].name

print("Input:", session.get_inputs()[0].shape)
print("Output:", session.get_outputs()[0].shape)

# 🔹 Dummy test input (match expected shape)
dummy_input = np.random.randint(0, 10, (1, 1, 30, 30)).astype(np.float32)

output = session.run([output_name], {input_name: dummy_input})

print("✅ Inference successful")
print("Output shape:", output[0].shape)